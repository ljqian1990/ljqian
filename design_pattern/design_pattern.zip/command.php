<?php
/**
 * ����ģʽ
 *
 * ��һ�������װΪһ������Ӷ�ʹ����ò�ͬ������Կͻ����в�����,�������ų����¼������־,�Լ�֧�ֿ�ȡ���Ĳ���
 */
interface Command {
	public function execute();
}
class Invoker {
	private $_command = array ();
	public function setCommand($command) {
		$this->_command [] = $command;
	}
	public function executeCommand() {
		foreach ( $this->_command as $command ) {
			$command->execute ();
		}
	}
	public function removeCommand($command) {
		$key = array_search ( $command, $this->_command );
		if ($key !== false) {
			unset ( $this->_command [$key] );
		}
	}
}
class Receiver {
	private $_name = null;
	public function __construct($name) {
		$this->_name = $name;
	}
	public function action() {
		echo $this->_name . " action<br/>";
	}
	public function action1() {
		echo $this->_name . " action1<br/>";
	}
}
class ConcreteCommand implements Command {
	private $_receiver;
	public function __construct($receiver) {
		$this->_receiver = $receiver;
	}
	public function execute() {
		$this->_receiver->action ();
	}
}
class ConcreteCommand1 implements Command {
	private $_receiver;
	public function __construct($receiver) {
		$this->_receiver = $receiver;
	}
	public function execute() {
		$this->_receiver->action1 ();
	}
}
class ConcreteCommand2 implements Command {
	private $_receiver;
	public function __construct($receiver) {
		$this->_receiver = $receiver;
	}
	public function execute() {
		$this->_receiver->action ();
		$this->_receiver->action1 ();
	}
}

$objRecevier = new Receiver ( "No.1" );
$objRecevier1 = new Receiver ( "No.2" );
$objRecevier2 = new Receiver ( "No.3" );

$objCommand = new ConcreteCommand ( $objRecevier );
$objCommand1 = new ConcreteCommand1 ( $objRecevier );
$objCommand2 = new ConcreteCommand ( $objRecevier1 );
$objCommand3 = new ConcreteCommand1 ( $objRecevier1 );
$objCommand4 = new ConcreteCommand2 ( $objRecevier2 ); // ʹ�� Recevier����������

$objInvoker = new Invoker ();
$objInvoker->setCommand ( $objCommand );
$objInvoker->setCommand ( $objCommand1 );
$objInvoker->executeCommand ();
$objInvoker->removeCommand ( $objCommand1 );
$objInvoker->executeCommand ();

$objInvoker->setCommand ( $objCommand2 );
$objInvoker->setCommand ( $objCommand3 );
$objInvoker->setCommand ( $objCommand4 );
$objInvoker->executeCommand ();